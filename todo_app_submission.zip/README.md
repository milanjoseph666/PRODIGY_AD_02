# To-Do List App

## Description
This is a simple GUI-based To-Do List application built using Python's Tkinter library. 
It allows users to:
- Add tasks
- Edit existing tasks
- Delete tasks

## How to Run
1. Make sure Python is installed.
2. Run the script using the command:
   python todo_app.py

## Requirements
- Python 3.x
- Tkinter (usually comes pre-installed with Python)

## Author
Prodigy Infotech Task-02 Submission
